/**
 * Tappd Mobile SDK (React Native)
 * Customer Data Platform SDK for iOS and Android applications
 */

import { AppState, AppStateStatus, Linking, Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DeviceInfo from 'react-native-device-info';

export interface TappdConfig {
  appId: string; // Required: App ID from dashboard
  apiUrl?: string; // Optional: Custom API URL
  autoTrack?: boolean; // Auto-track screen views (default: true)
  sessionTimeout?: number; // Session timeout in minutes (default: 30)
  enableAutoScreenTracking?: boolean; // Auto-track screen changes (default: true)
  debug?: boolean; // Enable debug logging
  enableInAppMessages?: boolean; // Enable/disable in-app message rendering (default: true)
  autoDisplayMessages?: boolean; // Automatically display pending messages (default: true)
  messagePollingInterval?: number; // Interval for polling new messages in seconds (default: 30)
}

export interface CustomerAttributes {
  external_id: string; // Required: Your internal user identifier
  name?: string;
  email?: string;
  phone?: string;
  [key: string]: any;
}

export interface EventProperties {
  [key: string]: any;
}

interface Session {
  sessionId: string;
  startedAt: number;
  lastActivityAt: number;
}

interface ScreenTracker {
  screenName: string;
  startTime: number;
}

export class TappdSDK {
  private appId: string;
  private apiUrl: string;
  private autoTrack: boolean;
  private sessionTimeout: number;
  private enableAutoScreenTracking: boolean;
  private debug: boolean;
  private enableInAppMessages: boolean;
  private autoDisplayMessages: boolean;
  private messagePollingInterval: number;
  
  private currentUserId: string | null = null;
  private anonymousId: string | null = null;
  private session: Session | null = null;
  private screenTracker: ScreenTracker | null = null;
  private appStateSubscription: any = null;
  private linkingSubscription: any = null;
  private displayedMessages: Set<string> = new Set();
  private messagePollingTimer: any = null;
  private messageRenderCallback: ((message: any) => void) | null = null;

  constructor(config: TappdConfig) {
    this.appId = config.appId;
    this.apiUrl = config.apiUrl || 'https://api.tappd.io/api/v1/sdk';
    this.autoTrack = config.autoTrack !== false;
    this.sessionTimeout = config.sessionTimeout || 30;
    this.enableAutoScreenTracking = config.enableAutoScreenTracking !== false;
    this.debug = config.debug || false;
    this.enableInAppMessages = config.enableInAppMessages !== false;
    this.autoDisplayMessages = config.autoDisplayMessages !== false;
    this.messagePollingInterval = config.messagePollingInterval || 30;

    if (!this.appId) {
      throw new Error('App ID is required');
    }

    // Initialize asynchronously
    this.initialize();
  }

  /**
   * Initialize SDK (async)
   */
  private async initialize() {
    try {
      // Get or create anonymous ID
      this.anonymousId = await this.getOrCreateAnonymousId();

      // Start new session
      this.startNewSession();

      // Setup app state listeners
      this.setupAppStateTracking();

      // Setup deep link tracking
      this.setupDeepLinkTracking();

      // Track app opened
      if (this.autoTrack) {
        await this.track('app.opened', {
          isFirstLaunch: await this.isFirstLaunch()
        });
      }

      // Initialize in-app messages if enabled
      if (this.enableInAppMessages) {
        this.initializeInAppMessages();
      }

      this.log('[Tappd SDK] Initialized with App ID:', this.appId.substring(0, 15) + '...');
    } catch (error) {
      this.log('[Tappd SDK] Initialization error:', error);
    }
  }

  /**
   * Get or create anonymous ID (stored in AsyncStorage)
   */
  private async getOrCreateAnonymousId(): Promise<string> {
    const key = '_tappd_anonymous_id';
    try {
      let anonymousId = await AsyncStorage.getItem(key);
      
      if (!anonymousId) {
        anonymousId = 'anon_' + Math.random().toString(36).substring(2, 15) + Date.now().toString(36);
        await AsyncStorage.setItem(key, anonymousId);
      }

      return anonymousId;
    } catch (error) {
      // Fallback if AsyncStorage fails
      this.log('[Tappd SDK] AsyncStorage error, using in-memory ID:', error);
      return 'anon_' + Math.random().toString(36).substring(2, 15) + Date.now().toString(36);
    }
  }

  /**
   * Check if this is first launch
   */
  private async isFirstLaunch(): Promise<boolean> {
    try {
      const key = '_tappd_first_launch';
      const value = await AsyncStorage.getItem(key);
      
      if (value === null) {
        await AsyncStorage.setItem(key, 'false');
        return true;
      }
      
      return false;
    } catch (error) {
      return false;
    }
  }

  /**
   * Start a new session
   */
  private startNewSession() {
    const sessionId = 'sess_' + Math.random().toString(36).substring(2, 15) + Date.now().toString(36);
    
    this.session = {
      sessionId,
      startedAt: Date.now(),
      lastActivityAt: Date.now()
    };

    this.log('[Tappd SDK] New session started:', sessionId.substring(0, 15));
  }

  /**
   * Check if session has expired and start a new one if needed
   */
  private checkAndRefreshSession() {
    if (!this.session) {
      this.startNewSession();
      return;
    }

    const elapsed = Date.now() - this.session.lastActivityAt;
    const timeoutMs = this.sessionTimeout * 60 * 1000;

    if (elapsed > timeoutMs) {
      this.log('[Tappd SDK] Session expired, starting new session');
      this.startNewSession();
    }
  }

  /**
   * Update session activity
   */
  private updateSessionActivity() {
    if (this.session) {
      this.session.lastActivityAt = Date.now();
    }
  }

  /**
   * Setup app state tracking (foreground/background)
   */
  private setupAppStateTracking() {
    // Track current app state
    const handleAppStateChange = async (nextAppState: AppStateStatus) => {
      if (nextAppState === 'active') {
        // App came to foreground
        this.checkAndRefreshSession();
        this.updateSessionActivity();
        
        if (this.autoTrack) {
          await this.track('app.foreground', {});
        }
      } else if (nextAppState === 'background' || nextAppState === 'inactive') {
        // App went to background
        if (this.autoTrack) {
          await this.track('app.background', {});
        }
        
        // End current screen tracking
        if (this.screenTracker) {
          const duration = Math.floor((Date.now() - this.screenTracker.startTime) / 1000);
          await this.track('screen.viewed', {
            screenName: this.screenTracker.screenName,
            duration
          });
          this.screenTracker = null;
        }
      }
    };

    // Subscribe to app state changes
    this.appStateSubscription = AppState.addEventListener('change', handleAppStateChange);
  }

  /**
   * Setup deep link tracking
   */
  private setupDeepLinkTracking() {
    // Get initial URL if app was opened via deep link
    Linking.getInitialURL().then((url) => {
      if (url) {
        this.handleDeepLink(url);
      }
    });

    // Listen for deep links while app is running
    this.linkingSubscription = Linking.addEventListener('url', (event: { url: string }) => {
      this.handleDeepLink(event.url);
    });
  }

  /**
   * Handle deep link
   */
  private async handleDeepLink(url: string): Promise<void> {
    try {
      const urlObj = new URL(url);
      const utm: Record<string, string> = {};
      
      // Extract UTM parameters
      ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content'].forEach(param => {
        const value = urlObj.searchParams.get(param);
        if (value) {
          utm[param.replace('utm_', '')] = value;
        }
      });

      await this.track('deep_link.opened', {
        url,
        path: urlObj.pathname,
        utm: Object.keys(utm).length > 0 ? utm : undefined
      });
    } catch (error) {
      this.log('[Tappd SDK] Deep link error:', error);
    }
  }

  /**
   * Get basic device information for event tracking
   */
  private getDeviceInfo() {
    return {
      platform: Platform.OS,
      version: Platform.Version,
    };
  }

  /**
   * Get rich device information for push registration
   */
  private async getFullDeviceInfo() {
    try {
      const [carrier] = await Promise.all([
        DeviceInfo.getCarrier().catch(() => undefined),
      ]);

      return {
        deviceId: await this.getOrCreateDeviceId(),
        platform: Platform.OS,
        osName: DeviceInfo.getSystemName(),
        osVersion: String(DeviceInfo.getSystemVersion()),
        deviceModel: DeviceInfo.getModel(),
        deviceBrand: DeviceInfo.getBrand(),
        deviceName: await DeviceInfo.getDeviceName().catch(() => undefined),
        carrier: carrier,
      };
    } catch (error) {
      this.log('[Tappd SDK] getFullDeviceInfo error:', error);
      // Fallback to minimal info
      return {
        deviceId: await this.getOrCreateDeviceId(),
        platform: Platform.OS,
        osName: undefined,
        osVersion: String(Platform.Version),
        deviceModel: undefined,
        deviceBrand: undefined,
        deviceName: undefined,
        carrier: undefined,
      };
    }
  }

  /**
   * Identify a user
   * Requires external_id in attributes - SDK will generate internal userId automatically
   */
  async identify(attributes: CustomerAttributes): Promise<void> {
    try {
      if (!attributes?.external_id) {
        throw new Error('external_id is required in attributes');
      }

      // Store external_id for future use
      await this.setExternalId(attributes.external_id);

      // Generate internal userId (use external_id as base)
      // API will create/find customer by external_id and return/create userId
      const internalUserId = `usr_${attributes.external_id}`;
      this.currentUserId = internalUserId;

      const response = await this.post('/identify', {
        external_id: attributes.external_id,
        name: attributes?.name,
        email: attributes?.email,
        phone: attributes?.phone,
        anonymousId: this.anonymousId, // Include anonymous ID for merging
        attributes: this.extractCustomAttributes(attributes)
      });

      // Store the returned userId if API generates one
      if (response?.data?.userId) {
        this.currentUserId = response.data.userId;
      }

      this.log('[Tappd SDK] Customer identified:', attributes.external_id);
      
      return response;
    } catch (error) {
      this.log('[Tappd SDK] Identify error:', error);
      throw error;
    }
  }

  /**
   * Store external ID in AsyncStorage
   */
  private async setExternalId(externalId: string): Promise<void> {
    try {
      await AsyncStorage.setItem('_tappd_external_id', externalId);
    } catch (error) {
      this.log('[Tappd SDK] Failed to store external_id:', error);
    }
  }

  /**
   * Get stored external ID
   */
  private async getExternalId(): Promise<string | null> {
    try {
      return await AsyncStorage.getItem('_tappd_external_id');
    } catch {
      return null;
    }
  }

  /**
   * Update user attributes
   */
  async setUserAttributes(attributes: Partial<CustomerAttributes>): Promise<void> {
    if (!this.currentUserId) {
      throw new Error('User must be identified first. Call identify() first.');
    }
    
    // Get existing external_id from storage or require it
    const existingExternalId = await this.getExternalId();
    if (!existingExternalId && !attributes.external_id) {
      throw new Error('external_id is required. User must be identified first.');
    }
    
    return this.identify({
      external_id: attributes.external_id || existingExternalId!,
      ...attributes
    } as CustomerAttributes);
  }

  /**
   * Set custom attributes only (doesn't require external_id)
   */
  async setCustomAttributes(attributes: Record<string, any>): Promise<void> {
    if (!this.currentUserId) {
      throw new Error('User must be identified first. Call identify() first.');
    }
    
    const existingExternalId = await this.getExternalId();
    if (!existingExternalId) {
      throw new Error('User must be identified first. Call identify() first.');
    }
    
    return this.identify({
      external_id: existingExternalId,
      ...attributes
    } as CustomerAttributes);
  }

  /**
   * Track an event with automatic session management
   */
  async track(eventName: string, properties?: EventProperties): Promise<void> {
    try {
      // Check if session expired
      this.checkAndRefreshSession();

      if (!this.session) {
        this.startNewSession();
      }

      // Update session activity
      this.updateSessionActivity();

      const deviceInfo = this.getDeviceInfo();
      const userId = this.currentUserId || this.anonymousId;
      
      // If identified, also send external_id for lookup
      const externalId = await this.getExternalId();

      // Calculate session duration
      const sessionDuration = this.session ? Math.floor((Date.now() - this.session.startedAt) / 1000) : 0;

      const response = await this.post('/track', {
        eventName,
        properties: properties || {},
        sessionId: this.session?.sessionId,
        sessionStartTime: this.session?.startedAt,
        sessionDuration,
        userId,
        external_id: externalId,  // Include external_id if available
        ...deviceInfo
      });

      this.log('[Tappd SDK] Event tracked:', eventName);
      
      return response;
    } catch (error) {
      this.log('[Tappd SDK] Track error:', error);
      // Don't throw - tracking failures shouldn't break the app
    }
  }

  /**
   * Track screen view (equivalent to page view in web)
   */
  async trackScreen(screenName: string, properties?: EventProperties): Promise<void> {
    try {
      // End previous screen tracking if exists
      if (this.screenTracker) {
        const duration = Math.floor((Date.now() - this.screenTracker.startTime) / 1000);
        await this.track('screen.viewed', {
          screenName: this.screenTracker.screenName,
          duration,
          ...properties
        });
      }

      // Check if session expired
      this.checkAndRefreshSession();

      if (!this.session) {
        this.startNewSession();
      }

      // Update session activity
      this.updateSessionActivity();

      // Start new screen tracking
      this.screenTracker = {
        screenName,
        startTime: Date.now()
      };

      const userId = this.currentUserId || this.anonymousId;
      
      // If identified, also send external_id for lookup
      const externalId = await this.getExternalId();
      
      const sessionDuration = this.session ? Math.floor((Date.now() - this.session.startedAt) / 1000) : 0;

      const response = await this.post('/screen', {
        screenName,
        sessionId: this.session?.sessionId,
        sessionStartTime: this.session?.startedAt,
        sessionDuration,
        userId,
        external_id: externalId,  // Include external_id if available
        ...properties
      });

      this.log('[Tappd SDK] Screen tracked:', screenName);
      
      return response;
    } catch (error) {
      this.log('[Tappd SDK] Track screen error:', error);
    }
  }

  /**
   * Get session ID
   */
  getSessionId(): string | null {
    return this.session?.sessionId || null;
  }

  /**
   * Get anonymous ID
   */
  getAnonymousId(): string | null {
    return this.anonymousId;
  }

  /**
   * Reset SDK (clear user data)
   */
  async reset(): Promise<void> {
    this.currentUserId = null;
    this.anonymousId = null;
    this.screenTracker = null;
    this.startNewSession();
    
    // Clear stored IDs
    await AsyncStorage.multiRemove(['_tappd_anonymous_id', '_tappd_external_id']).catch(() => {});
    
    this.log('[Tappd SDK] Reset');
  }

  /**
   * Cleanup (call when app is closing)
   */
  cleanup(): void {
    // Remove listeners
    if (this.appStateSubscription) {
      this.appStateSubscription.remove();
    }
    
    if (this.linkingSubscription) {
      this.linkingSubscription.remove();
    }

    // Track app closed
    if (this.autoTrack && this.session) {
      const sessionDuration = Math.floor((Date.now() - this.session.startedAt) / 1000);
      this.track('app.closed', {
        sessionDuration
      }).catch(() => {});
    }

    // End current screen tracking
    if (this.screenTracker) {
      const duration = Math.floor((Date.now() - this.screenTracker.startTime) / 1000);
      this.track('screen.viewed', {
        screenName: this.screenTracker.screenName,
        duration
      }).catch(() => {});
    }
  }

  /**
   * Extract custom attributes (exclude standard fields)
   */
  private extractCustomAttributes(attributes: CustomerAttributes): Record<string, any> {
    const { external_id, name, email, phone, ...custom } = attributes;
    return custom;
  }

  /**
   * Make POST request
   */
  private async post(endpoint: string, data: any): Promise<any> {
    try {
      // Add appId to the payload
      const payload = {
        ...data,
        appId: this.appId
      };

      const response = await fetch(`${this.apiUrl}${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        throw new Error(`Request failed: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      this.log('Request error:', error);
      throw error;
    }
  }

  /**
   * Register push token for push notifications
   */
  async registerPushToken(token: string, platform: 'android' | 'ios'): Promise<void> {
    try {
      if (!token || !platform) {
        throw new Error('Push token and platform are required');
      }

      const userId = this.currentUserId || this.anonymousId;
      const externalId = await this.getExternalId();
      const deviceInfo = await this.getFullDeviceInfo();

      if (!userId) {
        throw new Error('User must be identified first');
      }

      const response = await this.post('/register-device', {
        userId,
        external_id: externalId,  // Include external_id if available
        pushToken: token,
        platform,
        deviceId: deviceInfo.deviceId,
        deviceModel: deviceInfo.deviceModel,
        deviceBrand: deviceInfo.deviceBrand,
        deviceName: deviceInfo.deviceName,
        osName: deviceInfo.osName,
        osVersion: deviceInfo.osVersion,
        carrier: deviceInfo.carrier,
        metadata: {
          sdk: 'tappd-mobile-sdk',
          sdkVersion: '1.0.0',
        },
      });

      this.log('[Tappd SDK] Push token registered:', token.substring(0, 20) + '...');
      return response;
    } catch (error) {
      this.log('[Tappd SDK] Register push token error:', error);
      throw error;
    }
  }

  /**
   * Check push subscription status
   */
  async checkPushSubscription(): Promise<{ subscribed: boolean; status: string; deviceCount: number }> {
    try {
      const userId = this.currentUserId || this.anonymousId;
      const externalId = await this.getExternalId();

      if (!userId) {
        throw new Error('User must be identified first');
      }

      const response = await this.get('/push-subscription-status', {
        userId,
        external_id: externalId,  // Include external_id if available
      });

      if (response.success && response.data) {
        return {
          subscribed: response.data.subscribed,
          status: response.data.status,
          deviceCount: response.data.deviceCount,
        };
      }

      throw new Error('Failed to get push subscription status');
    } catch (error) {
      this.log('[Tappd SDK] Check push subscription error:', error);
      throw error;
    }
  }

  /**
   * Get or create device ID (stored in AsyncStorage)
   */
  private async getOrCreateDeviceId(): Promise<string> {
    const key = '_tappd_device_id';
    try {
      let deviceId = await AsyncStorage.getItem(key);
      
      if (!deviceId) {
        deviceId = 'device_' + Math.random().toString(36).substring(2, 15) + Date.now().toString(36);
        await AsyncStorage.setItem(key, deviceId);
      }

      return deviceId;
    } catch (error) {
      // Fallback if AsyncStorage fails
      this.log('[Tappd SDK] AsyncStorage error, using in-memory device ID:', error);
      return 'device_' + Math.random().toString(36).substring(2, 15) + Date.now().toString(36);
    }
  }

  /**
   * Make GET request
   */
  private async get(endpoint: string, params?: Record<string, any>): Promise<any> {
    try {
      const queryString = params ? '?' + new URLSearchParams(params).toString() : '';
      const url = `${this.apiUrl}${endpoint}${queryString}`;

      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'X-App-Id': this.appId,
        },
      });

      if (!response.ok) {
        throw new Error(`Request failed: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      this.log('Request error:', error);
      throw error;
    }
  }

  /**
   * Log debug messages
   */
  private log(...args: any[]): void {
    if (this.debug) {
      console.log('[Tappd SDK]', ...args);
    }
  }

  /**
   * Set callback for rendering messages (called by app)
   */
  setMessageRenderCallback(callback: (message: any) => void): void {
    this.messageRenderCallback = callback;
  }

  /**
   * Initialize in-app messages
   */
  private initializeInAppMessages(): void {
    // Start polling if auto-display is enabled
    if (this.autoDisplayMessages) {
      // Initial fetch after a short delay
      setTimeout(() => {
        this.displayPendingMessages().catch((error) => {
          this.log('[Tappd SDK] Error displaying pending messages:', error);
        });
      }, 1000);

      // Set up polling
      this.startMessagePolling();
    }
  }

  /**
   * Start message polling
   */
  private startMessagePolling(): void {
    if (this.messagePollingTimer) {
      clearInterval(this.messagePollingTimer);
    }

    this.messagePollingTimer = setInterval(() => {
      this.displayPendingMessages().catch((error) => {
        this.log('[Tappd SDK] Error polling messages:', error);
      });
    }, this.messagePollingInterval * 1000);
  }

  /**
   * Stop message polling
   */
  private stopMessagePolling(): void {
    if (this.messagePollingTimer) {
      clearInterval(this.messagePollingTimer);
      this.messagePollingTimer = null;
    }
  }

  /**
   * Get pending in-app messages from API
   */
  async getInAppMessages(): Promise<any[]> {
    try {
      const userId = this.currentUserId || this.anonymousId;
      const externalId = await this.getExternalId();
      
      // Build query parameters
      const params: Record<string, string> = {};
      if (userId) params.userId = userId;
      if (externalId) params.externalId = externalId;

      const queryString = Object.keys(params).length > 0
        ? '?' + new URLSearchParams(params).toString()
        : '';
      const url = `${this.apiUrl}/in-app-messages${queryString}`;

      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'X-App-Id': this.appId,
        },
      });

      if (!response.ok) {
        throw new Error(`Request failed: ${response.statusText}`);
      }

      const result = await response.json();
      return result.data?.messages || [];
    } catch (error) {
      this.log('[Tappd SDK] Get in-app messages error:', error);
      throw error;
    }
  }

  /**
   * Display a single in-app message
   */
  async displayInAppMessage(message: any): Promise<void> {
    try {
      // Check if message has expired
      if (this.checkMessageExpiration(message)) {
        this.log('[Tappd SDK] Message expired, skipping:', message._id);
        return;
      }

      // Check if message is already displayed
      if (this.displayedMessages.has(message._id)) {
        this.log('[Tappd SDK] Message already displayed:', message._id);
        return;
      }

      // Evaluate trigger
      if (!this.evaluateTrigger(message.triggerConfig || message.config?.triggerConfig)) {
        this.log('[Tappd SDK] Trigger condition not met for message:', message._id);
        return;
      }

      // Call render callback if set
      if (this.messageRenderCallback) {
        this.messageRenderCallback(message);
      } else {
        this.log('[Tappd SDK] No message render callback set. Use setMessageRenderCallback() to render messages.');
      }

      // Mark as displayed
      this.displayedMessages.add(message._id);

      // Track viewed event
      await this.trackMessageEvent(message._id, 'viewed', {});

      // Mark as delivered in API
      await this.markMessageDelivered(message._id);

      this.log('[Tappd SDK] Message displayed:', message._id);
    } catch (error) {
      this.log('[Tappd SDK] Display message error:', error);
    }
  }

  /**
   * Display all pending messages
   */
  async displayPendingMessages(): Promise<void> {
    if (!this.enableInAppMessages) {
      return;
    }

    try {
      const messages = await this.getInAppMessages();
      
      // Filter out already displayed messages
      const newMessages = messages.filter(
        (msg) => !this.displayedMessages.has(msg._id)
      );

      // Display messages one by one
      for (const message of newMessages) {
        await this.displayInAppMessage(message);
      }
    } catch (error) {
      this.log('[Tappd SDK] Display pending messages error:', error);
    }
  }

  /**
   * Dismiss an in-app message
   */
  async dismissMessage(messageId: string): Promise<void> {
    try {
      // Remove from displayed set
      this.displayedMessages.delete(messageId);

      // Track dismissed event
      await this.trackMessageEvent(messageId, 'dismissed', {});

      // Mark as dismissed in API
      await this.markMessageDismissed(messageId);

      this.log('[Tappd SDK] Message dismissed:', messageId);
    } catch (error) {
      this.log('[Tappd SDK] Dismiss message error:', error);
    }
  }

  /**
   * Track message event
   */
  async trackMessageEvent(messageId: string, eventType: string, metadata: Record<string, any>): Promise<void> {
    try {
      await this.track(`message.${eventType}`, {
        messageId,
        ...metadata,
      });
    } catch (error) {
      this.log('[Tappd SDK] Track message event error:', error);
    }
  }

  /**
   * Mark message as delivered
   */
  private async markMessageDelivered(messageId: string): Promise<void> {
    try {
      const response = await fetch(`${this.apiUrl}/in-app-messages/${messageId}/delivered`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-App-Id': this.appId,
        },
      });

      if (!response.ok) {
        throw new Error(`Request failed: ${response.statusText}`);
      }
    } catch (error) {
      this.log('[Tappd SDK] Mark message delivered error:', error);
    }
  }

  /**
   * Mark message as dismissed
   */
  private async markMessageDismissed(messageId: string): Promise<void> {
    try {
      const response = await fetch(`${this.apiUrl}/in-app-messages/${messageId}/dismiss`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-App-Id': this.appId,
        },
      });

      if (!response.ok) {
        throw new Error(`Request failed: ${response.statusText}`);
      }
    } catch (error) {
      this.log('[Tappd SDK] Mark message dismissed error:', error);
    }
  }

  /**
   * Evaluate trigger conditions
   */
  private evaluateTrigger(triggerConfig: any): boolean {
    if (!triggerConfig || triggerConfig.type === 'immediate') {
      return true;
    }

    if (triggerConfig.type === 'delay') {
      // Delay triggers are handled server-side (triggeredAt)
      return true;
    }

    if (triggerConfig.type === 'event') {
      // Event triggers are checked when events are tracked
      return true;
    }

    return true;
  }

  /**
   * Check if message has expired
   */
  private checkMessageExpiration(message: any): boolean {
    if (!message.expiresAt) {
      return false;
    }

    const expiresAt = new Date(message.expiresAt);
    const now = new Date();

    return now > expiresAt;
  }
}

export default TappdSDK;
