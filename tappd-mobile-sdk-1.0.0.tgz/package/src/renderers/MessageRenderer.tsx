/**
 * Message Renderer for In-App Messages (React Native)
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  Modal,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Animated,
  ScrollView,
} from 'react-native';
import { BlockRendererComponent as BlockRenderer } from './BlockRenderer';
import type { InAppMessage, InAppMessageConfig } from '../types/inAppMessage';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

interface MessageRendererProps {
  message: InAppMessage;
  onDismiss: (messageId: string) => void;
  onButtonClick?: (messageId: string, link: string, text: string) => void;
}

/**
 * Get blocks from message config
 */
function getBlocks(config: InAppMessageConfig): any[] {
  // Support both legacy blocks and new pages structure
  if (config.pages && config.pages.length > 0) {
    // Use first page's blocks
    return config.pages[0].blocks || [];
  }
  return config.blocks || [];
}

/**
 * Banner Renderer Component
 */
export function BannerRenderer({ message, onDismiss, onButtonClick }: MessageRendererProps) {
  const config = message.config;
  const position = config.position || 'top';
  const blocks = getBlocks(config);
  const [fadeAnim] = useState(new Animated.Value(0));

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 300,
      useNativeDriver: true,
    }).start();
  }, []);

  const containerStyle: any = {
    position: 'absolute',
    left: 0,
    right: 0,
    width: '100%',
    zIndex: 9999,
    backgroundColor: config.backgroundColor || '#FFFFFF',
    padding: 12,
    borderBottomWidth: position === 'top' ? 1 : 0,
    borderTopWidth: position === 'bottom' ? 1 : 0,
    borderColor: '#E0E0E0',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
  };

  if (position === 'top') {
    containerStyle.top = 0;
  } else if (position === 'bottom') {
    containerStyle.bottom = 0;
  } else {
    containerStyle.top = SCREEN_HEIGHT / 2;
    containerStyle.transform = [{ translateY: -100 }];
  }

  return (
    <Animated.View style={[containerStyle, { opacity: fadeAnim }]}>
      <View style={styles.bannerContent}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.bannerScroll}>
          {blocks.map((block) => (
            <BlockRenderer
              key={block.id}
              block={block}
              onButtonClick={(link, text) => {
                if (onButtonClick) {
                  onButtonClick(message._id, link, text);
                }
              }}
            />
          ))}
        </ScrollView>
        {config.dismissible !== false && (
          <TouchableOpacity
            style={styles.dismissButton}
            onPress={() => onDismiss(message._id)}
          >
            <Text style={styles.dismissButtonText}>×</Text>
          </TouchableOpacity>
        )}
      </View>
    </Animated.View>
  );
}

/**
 * Popup Renderer Component
 */
export function PopupRenderer({ message, onDismiss, onButtonClick }: MessageRendererProps) {
  const config = message.config;
  const blocks = getBlocks(config);
  const overlay = config.overlay !== false;
  const overlayOpacity = config.overlayOpacity || 0.5;
  const [fadeAnim] = useState(new Animated.Value(0));
  const [scaleAnim] = useState(new Animated.Value(0.9));

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }),
      Animated.spring(scaleAnim, {
        toValue: 1,
        friction: 8,
        tension: 40,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const handleOverlayPress = () => {
    if (config.dismissible !== false) {
      onDismiss(message._id);
    }
  };

  return (
    <Modal
      transparent
      visible
      animationType="none"
      onRequestClose={() => {
        if (config.dismissible !== false) {
          onDismiss(message._id);
        }
      }}
    >
      <TouchableOpacity
        activeOpacity={1}
        style={[
          styles.overlay,
          { backgroundColor: overlay ? `rgba(0, 0, 0, ${overlayOpacity})` : 'transparent' },
        ]}
        onPress={handleOverlayPress}
      >
        <TouchableOpacity activeOpacity={1} onPress={(e) => e.stopPropagation()}>
          <Animated.View
            style={[
              styles.popupContainer,
              {
                opacity: fadeAnim,
                transform: [{ scale: scaleAnim }],
                backgroundColor: '#FFFFFF',
                maxWidth: SCREEN_WIDTH * 0.9,
                borderRadius: 8,
              },
            ]}
          >
            {config.closeButton !== false && (
              <TouchableOpacity
                style={styles.closeButton}
                onPress={() => onDismiss(message._id)}
              >
                <Text style={styles.closeButtonText}>×</Text>
              </TouchableOpacity>
            )}
            <ScrollView style={styles.popupContent}>
              {blocks.map((block) => (
                <BlockRenderer
                  key={block.id}
                  block={block}
                  onButtonClick={(link, text) => {
                    if (onButtonClick) {
                      onButtonClick(message._id, link, text);
                    }
                  }}
                />
              ))}
            </ScrollView>
          </Animated.View>
        </TouchableOpacity>
      </TouchableOpacity>
    </Modal>
  );
}

/**
 * Modal Renderer Component (similar to popup but larger)
 */
export function ModalRenderer({ message, onDismiss, onButtonClick }: MessageRendererProps) {
  const config = message.config;
  const blocks = getBlocks(config);
  const overlay = config.overlay !== false;
  const overlayOpacity = config.overlayOpacity || 0.5;
  const [fadeAnim] = useState(new Animated.Value(0));
  const [scaleAnim] = useState(new Animated.Value(0.9));

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }),
      Animated.spring(scaleAnim, {
        toValue: 1,
        friction: 8,
        tension: 40,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const handleOverlayPress = () => {
    if (config.dismissible !== false) {
      onDismiss(message._id);
    }
  };

  return (
    <Modal
      transparent
      visible
      animationType="none"
      onRequestClose={() => {
        if (config.dismissible !== false) {
          onDismiss(message._id);
        }
      }}
    >
      <TouchableOpacity
        activeOpacity={1}
        style={[
          styles.overlay,
          { backgroundColor: overlay ? `rgba(0, 0, 0, ${overlayOpacity})` : 'transparent' },
        ]}
        onPress={handleOverlayPress}
      >
        <TouchableOpacity activeOpacity={1} onPress={(e) => e.stopPropagation()}>
          <Animated.View
            style={[
              styles.modalContainer,
              {
                opacity: fadeAnim,
                transform: [{ scale: scaleAnim }],
                backgroundColor: '#FFFFFF',
                maxWidth: SCREEN_WIDTH * 0.85,
                maxHeight: SCREEN_HEIGHT * 0.8,
                borderRadius: 8,
              },
            ]}
          >
            {config.closeButton !== false && (
              <TouchableOpacity
                style={styles.closeButton}
                onPress={() => onDismiss(message._id)}
              >
                <Text style={styles.closeButtonText}>×</Text>
              </TouchableOpacity>
            )}
            <ScrollView style={styles.modalContent}>
              {blocks.map((block) => (
                <BlockRenderer
                  key={block.id}
                  block={block}
                  onButtonClick={(link, text) => {
                    if (onButtonClick) {
                      onButtonClick(message._id, link, text);
                    }
                  }}
                />
              ))}
            </ScrollView>
          </Animated.View>
        </TouchableOpacity>
      </TouchableOpacity>
    </Modal>
  );
}

/**
 * Render a message based on its type
 */
export function MessageRenderer({ message, onDismiss, onButtonClick }: MessageRendererProps) {
  const config = message.config;
  const messageType = config.messageType || 'popup';

  switch (messageType) {
    case 'banner':
      return <BannerRenderer message={message} onDismiss={onDismiss} onButtonClick={onButtonClick} />;
    case 'popup':
      return <PopupRenderer message={message} onDismiss={onDismiss} onButtonClick={onButtonClick} />;
    case 'modal':
      return <ModalRenderer message={message} onDismiss={onDismiss} onButtonClick={onButtonClick} />;
    default:
      return <PopupRenderer message={message} onDismiss={onDismiss} onButtonClick={onButtonClick} />;
  }
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  bannerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  bannerScroll: {
    flex: 1,
  },
  dismissButton: {
    padding: 4,
    marginLeft: 8,
  },
  dismissButtonText: {
    fontSize: 24,
    color: '#666',
    lineHeight: 24,
  },
  popupContainer: {
    padding: 20,
    width: '90%',
    maxWidth: 500,
  },
  popupContent: {
    marginTop: 8,
  },
  modalContainer: {
    padding: 24,
    width: '85%',
    maxWidth: 600,
  },
  modalContent: {
    marginTop: 8,
  },
  closeButton: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 32,
    height: 32,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 10,
  },
  closeButtonText: {
    fontSize: 28,
    color: '#666',
    lineHeight: 28,
  },
});

